package com.example.rpginventorymaster

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MasterPanelActivity : AppCompatActivity() {

    private lateinit var recyclerViewPlayers: RecyclerView
    private lateinit var adapter: PlayerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_master_panel)

        recyclerViewPlayers = findViewById(R.id.recyclerViewPlayers)
        recyclerViewPlayers.layoutManager = LinearLayoutManager(this)

        // Inicializa o adapter com uma lista vazia
        adapter = PlayerAdapter(emptyList()) { player ->
            val intent = Intent(this, PlayerInventoryActivity::class.java)
            intent.putExtra("playerId", player.id)
            intent.putExtra("playerName", player.name)
            startActivity(intent)
        }
        recyclerViewPlayers.adapter = adapter

        // Obter a instância do banco de dados e o DAO
        val db = AppDatabase.getDatabase(this)
        val playerDao = db.playerDao()

        // Inserir um novo jogador (executado em background) para teste
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                val newPlayer = Player(name = "Novo Jogador", hp = 100, ca = 15, initiative = 2)
                playerDao.insertPlayer(newPlayer)
            }
        }

        // Observar a lista de jogadores e atualizar a RecyclerView
        lifecycleScope.launch {
            playerDao.getAllPlayers().collect { playersList ->
                // Atualiza o adapter com a nova lista de jogadores
                adapter = PlayerAdapter(playersList) { player ->
                    val intent = Intent(this@MasterPanelActivity, PlayerInventoryActivity::class.java)
                    intent.putExtra("playerId", player.id)
                    intent.putExtra("playerName", player.name)
                    startActivity(intent)
                }
                recyclerViewPlayers.adapter = adapter
            }
        }
    }
}
