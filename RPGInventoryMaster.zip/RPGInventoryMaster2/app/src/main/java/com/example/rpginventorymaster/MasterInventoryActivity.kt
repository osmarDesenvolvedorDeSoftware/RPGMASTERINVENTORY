package com.example.rpginventorymaster

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class MasterInventoryActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ItemAdapter
    private lateinit var textViewPlayerName: TextView
    private lateinit var buttonAddItem: Button
    private lateinit var buttonTransferItem: Button
    private lateinit var buttonRemoveItem: Button

    private var playerId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_master_inventory)

        // Recupera dados do jogador via Intent
        val playerName = intent.getStringExtra("playerName") ?: "Jogador"
        playerId = intent.getIntExtra("playerId", -1)

        textViewPlayerName = findViewById(R.id.textViewPlayerName)
        textViewPlayerName.text = "Inventário de $playerName"

        recyclerView = findViewById(R.id.recyclerViewMasterInventory)
        recyclerView.layoutManager = LinearLayoutManager(this)
        // Inicializa o adapter com uma lista vazia
        adapter = ItemAdapter(emptyList()) { item ->
            showItemOptionsDialog(item)
        }
        recyclerView.adapter = adapter

        buttonAddItem = findViewById(R.id.buttonAddItem)
        buttonTransferItem = findViewById(R.id.buttonTransferItem)
        buttonRemoveItem = findViewById(R.id.buttonRemoveItem)

        // Observa os itens persistidos e atualiza a RecyclerView
        val db = AppDatabase.getDatabase(this)
        val itemDao = db.itemDao()
        if (playerId != -1) {
            lifecycleScope.launch {
                itemDao.getItemsForPlayer(playerId).collect { items ->
                    adapter = ItemAdapter(items) { item ->
                        showItemOptionsDialog(item)
                    }
                    recyclerView.adapter = adapter
                }
            }
        }

        buttonAddItem.setOnClickListener { showAddItemDialog() }
        buttonRemoveItem.setOnClickListener { showRemoveItemDialog() }
        buttonTransferItem.setOnClickListener { showTransferItemDialog() }
    }

    private fun showItemOptionsDialog(item: Item) {
        val options = arrayOf("Editar", "Excluir")
        AlertDialog.Builder(this)
            .setTitle("Opções para ${item.name}")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showEditItemDialog(item)
                    1 -> confirmDeleteItem(item)
                }
            }
            .show()
    }

    private fun showEditItemDialog(item: Item) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_new_item, null)
        val editTextName = dialogView.findViewById<EditText>(R.id.editTextItemName)
        val editTextDescription = dialogView.findViewById<EditText>(R.id.editTextItemDescription)
        val editTextQuantity = dialogView.findViewById<EditText>(R.id.editTextItemQuantity)

        editTextName.setText(item.name)
        editTextDescription.setText(item.description)
        editTextQuantity.setText(item.quantity.toString())

        AlertDialog.Builder(this)
            .setTitle("Editar Item")
            .setView(dialogView)
            .setPositiveButton("Salvar") { _, _ ->
                val newName = editTextName.text.toString().trim()
                val newDescription = editTextDescription.text.toString().trim()
                val newQuantity = editTextQuantity.text.toString().toIntOrNull() ?: 0

                if (newName.isNotEmpty() && newQuantity > 0) {
                    val updatedItem = item.copy(
                        name = newName,
                        description = newDescription,
                        quantity = newQuantity
                    )
                    val db = AppDatabase.getDatabase(this)
                    val itemDao = db.itemDao()
                    lifecycleScope.launch(Dispatchers.IO) {
                        itemDao.updateItem(updatedItem)
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun confirmDeleteItem(item: Item) {
        AlertDialog.Builder(this)
            .setTitle("Excluir Item")
            .setMessage("Deseja remover ${item.name}?")
            .setPositiveButton("Excluir") { _, _ ->
                val db = AppDatabase.getDatabase(this)
                val itemDao = db.itemDao()
                lifecycleScope.launch(Dispatchers.IO) {
                    itemDao.deleteItem(item)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showAddItemDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_new_item, null)
        val editTextName = dialogView.findViewById<EditText>(R.id.editTextItemName)
        val editTextDescription = dialogView.findViewById<EditText>(R.id.editTextItemDescription)
        val editTextQuantity = dialogView.findViewById<EditText>(R.id.editTextItemQuantity)

        AlertDialog.Builder(this)
            .setTitle("Adicionar Item")
            .setView(dialogView)
            .setPositiveButton("Adicionar") { _, _ ->
                val name = editTextName.text.toString().trim()
                val description = editTextDescription.text.toString().trim()
                val quantity = editTextQuantity.text.toString().toIntOrNull() ?: 0

                if (name.isNotEmpty() && quantity > 0 && playerId != -1) {
                    val newItem = Item(
                        name = name,
                        description = description,
                        quantity = quantity,
                        playerId = playerId
                    )
                    val db = AppDatabase.getDatabase(this)
                    val itemDao = db.itemDao()
                    lifecycleScope.launch(Dispatchers.IO) {
                        itemDao.insertItem(newItem)
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // Função para o botão "Remover"
    private fun showRemoveItemDialog() {
        if (adapter.itemCount > 0) {
            // Exemplo: remove o primeiro item da lista
            val itemToRemove = adapter.items.first()
            confirmDeleteItem(itemToRemove)
        } else {
            AlertDialog.Builder(this)
                .setMessage("Nenhum item para remover.")
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun showTransferItemDialog() {
        if (adapter.itemCount > 0) {
            val itemToTransfer = adapter.items.first() // Exemplo: transfere o primeiro item
            val newPlayerId = 999  // Exemplo: novo destino (ajuste conforme necessário)
            AlertDialog.Builder(this)
                .setTitle("Transferir Item")
                .setMessage("Transferir ${itemToTransfer.name} para o jogador com ID $newPlayerId?")
                .setPositiveButton("Transferir") { _, _ ->
                    val transferredItem = itemToTransfer.copy(playerId = newPlayerId)
                    val db = AppDatabase.getDatabase(this)
                    val itemDao = db.itemDao()
                    lifecycleScope.launch(Dispatchers.IO) {
                        itemDao.updateItem(transferredItem)
                    }
                }
                .setNegativeButton("Cancelar", null)
                .show()
        } else {
            AlertDialog.Builder(this)
                .setMessage("Nenhum item para transferir.")
                .setPositiveButton("OK", null)
                .show()
        }
    }
}
