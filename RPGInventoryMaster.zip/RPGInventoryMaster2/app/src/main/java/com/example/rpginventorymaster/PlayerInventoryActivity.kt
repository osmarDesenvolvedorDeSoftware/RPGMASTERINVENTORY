package com.example.rpginventorymaster

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlayerInventoryActivity : AppCompatActivity() {

    private lateinit var recyclerViewItems: RecyclerView
    private lateinit var adapter: ItemAdapter
    private var playerId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player_inventory)

        // Recupera os dados do jogador da Intent
        val playerName = intent.getStringExtra("playerName") ?: "Jogador"
        playerId = intent.getIntExtra("playerId", -1)

        val textViewInventoryTitle = findViewById<TextView>(R.id.textViewInventoryTitle)
        textViewInventoryTitle.text = "Inventário de $playerName"

        recyclerViewItems = findViewById(R.id.recyclerViewItems)
        recyclerViewItems.layoutManager = LinearLayoutManager(this)
        // Inicializa o adapter com uma lista vazia e passa o callback para long press
        adapter = ItemAdapter(emptyList()) { item ->
            showItemOptionsDialog(item)
        }
        recyclerViewItems.adapter = adapter

        // Observa os itens persistidos e atualiza a RecyclerView
        val db = AppDatabase.getDatabase(this)
        val itemDao = db.itemDao()

        if (playerId != -1) {
            lifecycleScope.launch {
                itemDao.getItemsForPlayer(playerId).collect { items ->
                    adapter = ItemAdapter(items) { item ->
                        showItemOptionsDialog(item)
                    }
                    recyclerViewItems.adapter = adapter
                }
            }
        }

        // Se desejar, você também pode configurar um FAB para adicionar novos itens
        val fabAddItem = findViewById<FloatingActionButton>(R.id.fabAddItem)
        fabAddItem.setOnClickListener { showAddItemDialog() }
    }

    private fun showItemOptionsDialog(item: Item) {
        val options = arrayOf("Editar", "Excluir")
        AlertDialog.Builder(this)
            .setTitle("Opções para ${item.name}")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> showEditItemDialog(item)
                    1 -> confirmDeleteItem(item)
                }
            }
            .show()
    }

    private fun showEditItemDialog(item: Item) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_new_item, null)
        val editTextName = dialogView.findViewById<EditText>(R.id.editTextItemName)
        val editTextDescription = dialogView.findViewById<EditText>(R.id.editTextItemDescription)
        val editTextQuantity = dialogView.findViewById<EditText>(R.id.editTextItemQuantity)

        // Preenche os campos com os dados atuais do item
        editTextName.setText(item.name)
        editTextDescription.setText(item.description)
        editTextQuantity.setText(item.quantity.toString())

        AlertDialog.Builder(this)
            .setTitle("Editar Item")
            .setView(dialogView)
            .setPositiveButton("Salvar") { _, _ ->
                val newName = editTextName.text.toString().trim()
                val newDescription = editTextDescription.text.toString().trim()
                val newQuantity = editTextQuantity.text.toString().toIntOrNull() ?: 0

                if (newName.isNotEmpty() && newQuantity > 0) {
                    val updatedItem = item.copy(
                        name = newName,
                        description = newDescription,
                        quantity = newQuantity
                    )
                    val db = AppDatabase.getDatabase(this)
                    val itemDao = db.itemDao()
                    lifecycleScope.launch(Dispatchers.IO) {
                        itemDao.updateItem(updatedItem)
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun confirmDeleteItem(item: Item) {
        AlertDialog.Builder(this)
            .setTitle("Excluir Item")
            .setMessage("Tem certeza que deseja excluir ${item.name}?")
            .setPositiveButton("Excluir") { _, _ ->
                val db = AppDatabase.getDatabase(this)
                val itemDao = db.itemDao()
                lifecycleScope.launch(Dispatchers.IO) {
                    itemDao.deleteItem(item)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showAddItemDialog() {
        // Essa função pode ser igual à implementada anteriormente para adicionar itens
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_new_item, null)
        val editTextName = dialogView.findViewById<EditText>(R.id.editTextItemName)
        val editTextDescription = dialogView.findViewById<EditText>(R.id.editTextItemDescription)
        val editTextQuantity = dialogView.findViewById<EditText>(R.id.editTextItemQuantity)

        AlertDialog.Builder(this)
            .setTitle("Novo Item")
            .setView(dialogView)
            .setPositiveButton("Adicionar") { _, _ ->
                val name = editTextName.text.toString().trim()
                val description = editTextDescription.text.toString().trim()
                val quantity = editTextQuantity.text.toString().toIntOrNull() ?: 0

                if (name.isNotEmpty() && quantity > 0 && playerId != -1) {
                    val newItem = Item(
                        name = name,
                        description = description,
                        quantity = quantity,
                        playerId = playerId
                    )
                    val db = AppDatabase.getDatabase(this)
                    val itemDao = db.itemDao()
                    lifecycleScope.launch(Dispatchers.IO) {
                        itemDao.insertItem(newItem)
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
