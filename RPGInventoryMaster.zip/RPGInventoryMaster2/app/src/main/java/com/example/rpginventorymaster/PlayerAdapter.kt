package com.example.rpginventorymaster

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PlayerAdapter(
    private val players: List<Player>,
    private val onItemClick: (Player) -> Unit  // Função para tratar o clique
) : RecyclerView.Adapter<PlayerAdapter.PlayerViewHolder>() {

    class PlayerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewPlayerName: TextView = itemView.findViewById(R.id.textViewPlayerName)
        val textViewPlayerInfo: TextView = itemView.findViewById(R.id.textViewPlayerInfo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlayerViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_player, parent, false)
        return PlayerViewHolder(view)
    }

    override fun onBindViewHolder(holder: PlayerViewHolder, position: Int) {
        val player = players[position]
        holder.textViewPlayerName.text = player.name
        holder.textViewPlayerInfo.text = "HP: ${player.hp} | CA: ${player.ca} | Iniciativa: +${player.initiative}"
        holder.itemView.setOnClickListener {
            onItemClick(player)
        }
    }

    override fun getItemCount(): Int = players.size
}
