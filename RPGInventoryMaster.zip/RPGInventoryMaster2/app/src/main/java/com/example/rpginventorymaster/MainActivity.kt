package com.example.rpginventorymaster

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Ajusta os insets para a tela
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Referências dos elementos da tela
        val editTextUsername = findViewById<EditText>(R.id.editTextUsername)
        val editTextPassword = findViewById<EditText>(R.id.editTextPassword)
        val radioGroupPerfil = findViewById<RadioGroup>(R.id.radioGroupPerfil)
        val buttonEntrar = findViewById<Button>(R.id.buttonEntrar)

        buttonEntrar.setOnClickListener {
            val username = editTextUsername.text.toString().trim()
            val password = editTextPassword.text.toString().trim()

            // Validação simples
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Preencha usuário e senha", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val selectedId = radioGroupPerfil.checkedRadioButtonId
            if (selectedId == -1) {
                Toast.makeText(this, "Selecione um perfil", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val perfilSelecionado = if (selectedId == R.id.radioMestre) "Mestre" else "Jogador"

            // Navegação de acordo com o perfil selecionado
            if (perfilSelecionado == "Mestre") {
                val intent = Intent(this, MasterPanelActivity::class.java)
                startActivity(intent)
            } else {
                val intent = Intent(this, PlayerInventoryActivity::class.java)
                startActivity(intent)
            }
        }
    }
}
